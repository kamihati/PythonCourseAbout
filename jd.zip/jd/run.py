# coding=utf8

from main import read_cate_to_db

if __name__ == "__main__":
    read_cate_to_db()

