# coding=utf8

# mysql配置
MySqlUser = 'root'
MySqlPwd = '123456'
MySqlPort = 3306
MySqlHost = "localhost"

# ms sqlServer配置
MsSqlHost = "192.168.0.221"
MsSqlUser = "new080"
MsSqlPwd = "uixgwpq*3mxgid*34pqs"

# 数据库名
db_name = "brnmall"

# 表名
# 类别表
cate_tb_name = 'cate'
item_tb_name = "item"

# sqlite3 数据库文件名
sqliteDbPath = 'jd.db'
